var apiKey = 'a54aae94377c86e67aec869bc86bc7dc',
	apiSecret = 'adbd7553cb5cb702f456fb7d63f79af8',
	baseURL = 'http://ws.audioscrobbler.com/2.0/';